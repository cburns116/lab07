This is the readme file.
PART 1: I chose to used lists because it will lay out the list of songs in an organized fashion. I made sure that each category had a class definition so I could eventually make it how I want it to look using a style tag or a css file. This is correct because it clearly lays out the information using the correct tags. 

PART 2: XML file was created by using my Part 1 as a template. By looking at the classes I created in Part 1 it was easy to assign new tags due to the lack of structure defined in XML tags. For example instead of class artist, i made the <artist> tag. 

Part 3: For part 3 I just used my part one html and added the css document to use as my style sheet. I made sure I edited the correct tags/classes in the css file making the correct changes to the html. I found this css to be pretty easy due to well structured code of lists.

Part 4: For my part four I made a css file and changed the approprite items on the file. I was not able to use that namespace html for images It always gave me an error no matter what I did. It works and formats but displays an error as well. I think there is just a syntax error displaying.I used the different tags I created for my xml css which worked out well.