So I went through my lab initially doing everything in the phpmyadmin because I didn't see we had to write down the each questions commmands.
By going back and redoing it, however, helped me understand the database a lot more  in SQL and made it much easier. When I did get stuck the documentation they provide you worked great.

Overall the lab was not too bad I just made sure to look up the correct commands and followed the lecture notes.


Work Cited:

SQL database error message pointed me to the manual which I used frequently:

http://dev.mysql.com/doc/refman/5.7/en/select.html

Also W3 schools helped me:
http://www.w3schools.com/sql/