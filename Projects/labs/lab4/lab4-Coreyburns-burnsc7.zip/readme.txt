This is the readme file for Corey Burns

I created my json and validated it by going to jsonlint and getting an approval

As far as my js I append each element from the Json which I loaded using get. I then add my css using the classes I insterted every <li>


Overall I used the click function for the picture then went through each element in my json and filled it in correctly based on appending it to the id. I then add a class in order to get the css to load correctly for my pictures and items. I like how this lay out is, it is easy to read all of the lists. 