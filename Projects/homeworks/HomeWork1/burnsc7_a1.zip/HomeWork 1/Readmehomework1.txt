Corey Burns
1. I selected XHTML 1.0 Strict because it is alot easier to maintain due to the strict XML. This is helpful because if I want to go back to this document and edit it I can due to nice XHTML.
2. Mine compares well to others I believe that my code is basic and easy to follow with simple CSS to edit the document.
3. I avoided divs and spans due to the nice layout of lists. I think this is very nice because logically a resume is just a list of accomplishments and skills you have. It is semanitcally correct becasue of the nice structure(lists) I used the hCard to create my telephone number in my information section ahead of the page
4. The hCard microformating was very helpful. It was simple formatting for resume style html. Personally I used the phone number example with spans and class= value to create the +1 and nice format of my phone number

References: 
Below is a collection of websites in which enabled me to complete this assignment 

-http://microformats.org/wiki/hcard(microformating)
-http://www.w3schools.com/(css refreshment)
-http://stackoverflow.com/(help understand image adding/positioning)
